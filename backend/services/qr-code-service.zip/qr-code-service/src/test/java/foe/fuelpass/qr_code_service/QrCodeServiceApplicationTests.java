package foe.fuelpass.qr_code_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrCodeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
