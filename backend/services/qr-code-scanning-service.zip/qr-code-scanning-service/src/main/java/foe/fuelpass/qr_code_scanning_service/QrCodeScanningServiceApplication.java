package foe.fuelpass.qr_code_scanning_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QrCodeScanningServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(QrCodeScanningServiceApplication.class, args);
	}

}
