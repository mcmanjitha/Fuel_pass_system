package foe.fuelpass.qr_code_scanning_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrCodeScanningServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
