package foe.fuelpass.motor_traffic_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorTrafficServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
