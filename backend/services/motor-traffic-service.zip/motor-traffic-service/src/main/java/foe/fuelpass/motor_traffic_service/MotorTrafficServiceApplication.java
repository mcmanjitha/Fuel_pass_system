package foe.fuelpass.motor_traffic_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorTrafficServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotorTrafficServiceApplication.class, args);
	}

}
