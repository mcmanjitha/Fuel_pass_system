package foe.fuelpass.fuel_quota_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelQuotaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
