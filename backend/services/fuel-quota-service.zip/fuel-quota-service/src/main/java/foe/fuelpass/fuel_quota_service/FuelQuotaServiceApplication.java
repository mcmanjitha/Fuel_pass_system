package foe.fuelpass.fuel_quota_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuelQuotaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuelQuotaServiceApplication.class, args);
	}

}
