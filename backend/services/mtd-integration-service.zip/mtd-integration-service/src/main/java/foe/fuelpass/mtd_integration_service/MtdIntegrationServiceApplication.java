package foe.fuelpass.mtd_integration_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtdIntegrationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtdIntegrationServiceApplication.class, args);
	}

}
