package foe.fuelpass.mtd_integration_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtdIntegrationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
